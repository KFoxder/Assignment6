/**
 * Test1 -- Example test class extending {@link TestHarness}
 * <p>
 * Tests toString method for graph
 * ***********************************************************************<br>
 * Computer Science 102: Data Structures<br>
 * New York University, Fall 2013,<br>
 * Lecturers: Eric Koskinen and Daniel Schwartz-Narbonne<br>
 * ***********************************************************************
 *
 * @author      Eric Koskinen       <ejk@cs.nyu.edu>
 * @version     $Revision$
 * @since       2013-11-25
 */

public class Test8 extends TestHarness {

    public Test8(String s) { super(s); }

    public boolean test() {
	Graph<String,String> g = new Graph<String,String>();


	try {
	    g.addNode("Kevin");
	    g.addNode("Mark");
	    g.addNode("Laura");
	    g.addBiEdge("Kevin", "Brother", "Mark");
	    g.addEdge("Kevin","Son","Laura");
	    g.addEdge("Laura", "Mother", "Kevin");
	    g.addEdge("Mark", "Son", "Laura");
	    g.addEdge("Laura", "Mother", "Mark");
	    System.out.println(g.toString());
	    
	   // if(g.toString().equals(""))
	  
	    
	    return false;
	    
	} catch (InvalidOperationException e) {
		e.printStackTrace();
	    return false;
	} catch (Exception e){
		e.printStackTrace();
		return false;
	}

	// Make sure n1's toStringWithEdges() works correctly
    }

}