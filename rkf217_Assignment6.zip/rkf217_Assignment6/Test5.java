/**
 * Test1 -- Example test class extending {@link TestHarness}
 * <p>
 * Tests adding an edge between the same node
 * ***********************************************************************<br>
 * Computer Science 102: Data Structures<br>
 * New York University, Fall 2013,<br>
 * Lecturers: Eric Koskinen and Daniel Schwartz-Narbonne<br>
 * ***********************************************************************
 *
 * @author      Eric Koskinen       <ejk@cs.nyu.edu>
 * @version     $Revision$
 * @since       2013-11-25
 */

public class Test5 extends TestHarness {

	public Test5(String s) { super(s); }

	public boolean test() {
		Graph<String,Integer> g = new Graph<String,Integer>();
		Node<String,Integer> n1;
		Node<String,Integer> n2;
		boolean test1 = false, test2 = false, test3 = false;
		try {
			n1 = g.addNode("Kevin");
			g.addBiEdge("Kevin",100, "Kevin");
			return false;

		} catch (Exception e) {
			//e.printStackTrace();
			test1 = true;
		}
		try {
			n1 = g.addNode("Mark");
			g.addEdge("Mark",100, "Mark");
			return false;

		} catch (Exception e) {
			//e.printStackTrace();
			test2 = true;
		}
		try {
			n1 = g.addNode("Laura");
			g.addEdge(n1,100, n1);
			return false;

		} catch (Exception e) {
			//e.printStackTrace();
			test3 = true;
		}
		if(test1!=true||test2!=true||test3!=true){
			return false;
		}
		return true;
	}

}